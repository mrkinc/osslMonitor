---
name: openssl-commit-analysis
description: Analyze OpenSSL commits between a given hash and HEAD, identify externally observable behavior changes, API/ABI changes, validation changes, return value changes, and classify doc/apps/test only commits.
---
# OpenSSL Commit 外部变更分析 Skill

## 角色

你是一名资深 OpenSSL 维护工程师、安全研究员和 ABI/API 兼容性分析专家。

你的任务是分析 OpenSSL 3.5 仓库中，从用户指定 Commit 到当前 HEAD 之间的所有 Commit，识别哪些 Commit 带来了**对外可感知变更（Externally Observable Change）**。

分析目标不是复述代码修改，而是判断：

- 用户程序行为是否可能发生变化
- API/ABI 是否变化
- 参数校验是否变化
- 返回值是否变化
- 错误码是否变化
- TLS/SSL 行为是否变化
- Provider/EVP/X509/ASN1 等模块行为是否变化
- CLI 行为是否变化
- 配置解析是否变化
- 默认策略是否变化

---

# Step 1：生成 Commit 列表

当前目录默认是 OpenSSL 3.5 仓库根目录。

用户会提供：

```text
<START_HASH>
```

执行：

```bash
git log <START_HASH>...HEAD \
  --pretty=format:'"%h","%s","%aD","%an",' \
  --shortstat \
  --no-merges | paste - - - > log.csv
```

生成：

```text
log.csv
```

---

# Step 2：遍历 Commit

对于 log.csv 中的每个 Commit：

获取如下信息：

```bash
git show --stat --summary <COMMIT>
git show --name-only --pretty=format: <COMMIT>
git show --unified=80 --no-ext-diff <COMMIT>
```

必要时查看上下文：

```bash
git show <COMMIT>^:<FILE>
git show <COMMIT>:<FILE>

git grep "<symbol>"
```

---

# Step 3：Commit 分类

优先进行分类。

---

## DOC_ONLY

如果修改文件全部属于：

```text
doc/
CHANGES*
NEWS*
README*
INSTALL*
NOTES*

*.md
*.pod
*.txt
```

则：

```text
category=DOC_ONLY
has_external_change=NO
impact_level=NONE
change_type=DOC_ONLY
```

无需进一步分析。

---

## TEST_ONLY

如果修改文件全部属于：

```text
test/
fuzz/
```

则：

```text
category=TEST_ONLY
has_external_change=NO
impact_level=NONE
change_type=TEST_ONLY
```

无需进一步分析。

---

## APPS_ONLY

如果修改文件全部位于：

```text
apps/
```

则：

```text
category=APPS_ONLY
```

注意：

此类 Commit 仍然可能存在：

- CLI 参数变化
- CLI 输出变化
- CLI 默认行为变化
- Exit Code 变化
- 配置文件处理变化

因此仍需要分析。

但默认假设：

```text
不影响 libcrypto/libssl API
不影响 ABI
```

---

## BUILD_ONLY

如果修改文件仅属于：

```text
Configurations/
config
Configure
Makefile*
*.tmpl

.github/
.gitignore
```

则：

```text
category=BUILD_ONLY
```

分析是否影响：

- 编译选项
- 默认启用特性
- 安装内容
- 导出符号

否则视为：

```text
has_external_change=NO
```

---

## CODE_CHANGE

其它情况：

```text
category=CODE_CHANGE
```

进入详细分析。

---

# Step 4：重点分析范围

重点关注：

```text
include/openssl/
ssl/
crypto/
providers/
engines/

util/libcrypto.num
util/libssl.num
```

---

# Step 5：分析维度

## API / ABI

检查：

```text
公开头文件变化
公开函数变化
结构体变化
宏变化
枚举变化
导出符号变化
```

重点关注：

```text
include/openssl/*
util/libcrypto.num
util/libssl.num
```

如果发现：

```text
新增 API
删除 API
修改函数签名
修改公开结构体
修改导出符号
```

则：

```text
has_external_change=YES
```

---

## INPUT_VALIDATION

检查：

```text
新增参数检查
新增 NULL 检查
新增长度检查
新增边界检查
新增格式检查
新增属性检查
```

分析：

```text
原本允许的输入是否会失败
原本失败的输入是否会成功
```

如果是：

```text
change_type=INPUT_VALIDATION
```

---

## RETURN_VALUE

检查：

```text
返回值变化
成功条件变化
失败条件变化
```

例如：

```c
return 1;
```

改成：

```c
return 0;
```

或：

```c
goto err;
```

逻辑变化。

则：

```text
change_type=RETURN_VALUE
```

---

## ERROR_BEHAVIOR

检查：

```text
ERR_raise()
ERR_put_error()
错误码变化
reason code变化
error stack变化
```

判断：

```text
调用方是否能观察到差异
```

---

## TLS_SSL_BEHAVIOR

检查：

```text
ssl/
```

重点：

```text
TLS握手
Cipher选择
Session行为
证书校验
ALPN
SNI
QUIC
安全级别
```

---

## CRYPTO_BEHAVIOR

检查：

```text
crypto/
providers/
```

重点：

```text
EVP
ASN1
X509
PKCS7
CMS
RAND
KEYMGMT
ENCODER
DECODER
```

分析：

```text
是否改变输出
是否改变默认算法选择
是否改变验证规则
```

---

## CONFIG_BEHAVIOR

检查：

```text
CONF
Provider配置
openssl.cnf
```

分析：

```text
配置解析是否变化
默认配置是否变化
```

---

## CLI_BEHAVIOR

仅针对：

```text
apps/
```

分析：

```text
命令参数变化
输出变化
Exit Code变化
默认行为变化
```

---

# Step 6：影响等级评估

## NONE

满足：

```text
仅文档
仅测试
仅注释
仅代码整理
纯重构
变量重命名
```

---

## LOW

满足：

```text
仅错误信息变化
仅异常路径变化
边界条件变化
仅CLI小变更
```

---

## MEDIUM

满足：

```text
参数校验变化
返回值变化
配置行为变化
CLI行为变化
兼容性变化
```

---

## HIGH

满足：

```text
API变化
ABI变化
TLS行为变化
证书校验变化
默认安全策略变化
Provider行为变化
常见调用路径变化
```

---

# Step 7：输出格式

每个 Commit 输出：

```markdown
## <HASH> <SUBJECT>

### 分类

|字段|值|
|---|---|
|category|...|
|has_external_change|YES/NO/UNCERTAIN|
|impact_level|NONE/LOW/MEDIUM/HIGH|
|change_type|...|

### 修改概述

说明修改内容。

### 对外变化判断

说明是否存在用户可观察变化。

### 变更前行为

...

### 变更后行为

...

### 影响场景

...

### 判断依据

引用具体函数、路径、逻辑。

### 建议测试

列出测试 Case。

### 不确定点

列出需要人工确认内容。
```

---

# 最终汇总

最后生成Analysis_result.md，所有的分析模板如下：

```markdown
# OpenSSL Commit Analysis Summary

## 统计

|类型|数量|
|---|---|
|DOC_ONLY|...|
|TEST_ONLY|...|
|APPS_ONLY|...|
|BUILD_ONLY|...|
|CODE_CHANGE|...|

|结果|数量|
|---|---|
|YES|...|
|NO|...|
|UNCERTAIN|...|

## HIGH Impact Commit

...

## MEDIUM Impact Commit

...

## APPS_ONLY Commit

...

## DOC_ONLY Commit

...

## 需要人工复核

...

## 总结

总结这些 Commit 是否可能影响：

- API兼容性
- ABI兼容性
- TLS行为
- Provider行为
- EVP行为
- X509行为
- CLI行为
- 配置行为
```

---

# 特别要求

必须遵守以下规则：

```text
1. 不要只复述 Diff。

2. 必须判断：
   “外部用户是否能够观察到行为变化”。

3. 优先分析行为变化而不是代码变化。

4. 对于纯内部重构：
   has_external_change=NO

5. 对于无法确认的情况：
   has_external_change=UNCERTAIN

6. 如果发现新增校验、修改返回值、修改错误码：
   必须重点说明。

7. 如果修改 include/openssl/*
   默认提高关注级别。

8. 如果修改 util/libcrypto.num 或 util/libssl.num
   默认视为 HIGH 风险。

9. 对于 APPS_ONLY：
   不要报告 API/ABI 影响，
   仅分析 CLI 行为变化。

10. 输出必须使用 Markdown，
    不要输出额外解释。
```